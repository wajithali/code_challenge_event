<?php 
/*Insert Json File Data*/

$connect = mysqli_connect("localhost", "root", "", "test_task");
?>